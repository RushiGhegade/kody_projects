
const  OPENBOXFORSTORESUERINFO = "storeUserInfo";
const  USERSTATUSKEY = "isLogin";
const  CURRENTLOGINUSERID  = "LoginUserId";