

import 'package:flutter/cupertino.dart';

class AppController{

  static TextEditingController searchController = TextEditingController();

}