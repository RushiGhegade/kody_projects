
enum Categories{
  all,
  watch,
  mobile,
  laptop,
  sound,
  airpodes,
  ac
}