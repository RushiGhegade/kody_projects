

import 'package:flutter/cupertino.dart';

class UserDummyInfo{

  String name;
  IconData iconData;

  UserDummyInfo({required this.name , required this.iconData});

}