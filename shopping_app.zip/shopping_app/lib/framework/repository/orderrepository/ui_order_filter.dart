

enum UiOrderFilter{
  All,
  Pending,
  Shipped,
  Delivered

}