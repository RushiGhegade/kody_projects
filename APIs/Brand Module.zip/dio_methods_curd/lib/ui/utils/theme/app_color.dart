
import 'package:flutter/material.dart';

class AppColor{

  static const  Color textColor = Colors.black;
  static const  Color white = Colors.white;
  static const  Color blue = Colors.blue;
  static const  Color black = Colors.black;
  static const  Color success = Colors.green;
  static const  Color error = Colors.red;
  static const  Color scaFoldBackgroundColor = Colors.white;

}