package com.example.dio_methods_curd

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
