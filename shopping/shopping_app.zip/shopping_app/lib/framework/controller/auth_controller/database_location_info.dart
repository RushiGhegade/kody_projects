
// here store the unique keys that required for store data
const  OPENBOXFORSTORESUERINFO = "storeUserInfo";
const  USERSTATUSKEY = "isLogin";
const  CURRENTLOGINUSERID  = "LoginUserId";