// store the all category filter
enum Categories{
  all,
  watch,
  mobile,
  laptop,
  sound,
  airpodes,
  ac
}