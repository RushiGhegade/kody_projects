

import 'package:flutter/cupertino.dart';

// it only dummmy in profile screen
class UserDummyInfo{

  String name;
  IconData iconData;

  UserDummyInfo({required this.name , required this.iconData});

}