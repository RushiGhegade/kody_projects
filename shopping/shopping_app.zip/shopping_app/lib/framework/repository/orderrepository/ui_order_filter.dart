

// these store order screen filter
enum UiOrderFilter{
  All,
  Pending,
  Shipped,
  Delivered

}